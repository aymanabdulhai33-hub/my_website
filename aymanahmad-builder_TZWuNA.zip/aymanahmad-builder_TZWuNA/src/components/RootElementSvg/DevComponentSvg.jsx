import react from "react";
import * as S from './styled'
import { useLocation } from "react-router-dom";

const DevComponentSvg = () => {

    const location = useLocation();
    const Path = location.pathname
    return(
        <S.Wrapper>
            <p className="Title">Dev Component</p>
            <svg width="20px" height="20px" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"className="Icon">
            <g id="SVGRepo_bgCarrier" strokeWidth="0"/>
            <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round"/>
            <g id="SVGRepo_iconCarrier"> 
            <g id="Layer_2" data-name="Layer 2"> 
            <g id="invisible_box" data-name="invisible box"> <rect width="48" height="48" fill="none"/> </g>
            <g id="icons_Q2" data-name="icons Q2"> 
            <path d="M42.9,12.2l-18-9L24,3l-.9.2-18,9a.1.1,0,0,0-.1.1l19,9.6,19-9.6A.1.1,0,0,0,42.9,12.2ZM26,25.4V44.2l16.9-8.6A1.9,1.9,0,0,0,44,33.8V16.3ZM4,16.3V33.8a1.9,1.9,0,0,0,1.1,1.8L22,44.2V25.4Z"/> </g> </g> </g>
            </svg>
        </S.Wrapper>
    )
}

export default DevComponentSvg