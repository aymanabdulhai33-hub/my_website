import react from "react";
import * as S from './styled'
import { useLocation } from "react-router-dom";

const OptionsSvg = () => {

    const location = useLocation();
    const Path = location.pathname
    return(
        <S.Wrapper>
        <svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

        <g id="SVGRepo_bgCarrier" strokeWidth="0"/>
        <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round"/>
        <g id="SVGRepo_iconCarrier"> <path d="M8 7C8.55228 7 9 7.44772 9 8V16C9 16.5523 8.55228 17 8 17C7.44772 17 7 16.5523 7 16V8C7 7.44772 7.44772 7 8 7Z" className="Icon"/> <path d="M17 16V8C17 7.44772 16.5523 7 16 7C15.4477 7 15 7.44772 15 8V16C15 16.5523 15.4477 17 16 17C16.5523 17 17 16.5523 17 16Z" 
        className="Icon"/> 
        <path fillRule="evenodd" clipRule="evenodd" d="M6.44444 2C3.98985 2 2 3.98985 2 6.44444V17.5556C2 20.0102 3.98985 22 6.44444 22H17.5556C20.0102 22 22 20.0102 22 17.5556V6.44444C22 3.98985 20.0102 2 17.5556 2H6.44444ZM17.5556 4H6.44444C5.09442 4 4 5.09442 4 6.44444V17.5556C4 18.9056 5.09442 20 6.44444 20H17.5556C18.9056 20 20 18.9056 20 17.5556V6.44444C20 5.09442 18.9056 4 17.5556 4Z" 
        className="Icon"/> <path d="M16 14.75C16.9665 14.75 17.75 13.9665 17.75 13C17.75 12.0335 16.9665 11.25 16 11.25C15.0335 11.25 14.25 12.0335 14.25 13C14.25 13.9665 15.0335 14.75 16 14.75ZM8 12.75C8.9665 12.75 9.75 11.9665 9.75 11C9.75 10.0335 8.9665 9.25 8 9.25C7.0335 9.25 6.25 10.0335 6.25 11C6.25 11.9665 7.0335 12.75 8 12.75Z"
        fill="white" className="IconStroke" strokeWidth="1.5"/> </g>
        </svg>
        <p className="Title">Options</p>
        </S.Wrapper>
    )
}

export default OptionsSvg